<?php


declare(strict_types=1);

namespace src;

class aa{
    public function __construct(){
        echo "aa loaded <br>";
    }
}