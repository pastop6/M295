port 55555

Listen 55555

<VirtualHost *:55555>
    DocumentRoot "C:\uek\xampp\htdocs\M295\COM_APP\public"
</VirtualHost>